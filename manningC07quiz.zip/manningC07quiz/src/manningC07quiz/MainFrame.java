package manningC07quiz;

/*
 * MainFrame.java - GUI for simple quiz of two players
 * 
 * author: Arthur T. Manning - amanning@emmaus.edu
 * (c) 2019 Emmaus Bible College
 * 
 * Description:
 * 
 * Demonstrate the used of arrays and ArrayLists as well as follow the specifications for a Question class
 * The Question class also has a UML class diagram required to be submitted with this project
 * 
 * This program presents quiz questions to the players, with an equal number of questions for each player
 * For it to work properly, the number of questions provided in the quiz creating method must be an even
 * multiple of the number of players.  The program determines the player number based on the number of the question.
 * 
 * Once the last question has been displayed, the scores are then listed for all players.
 * 
 * references:  Gaddis Java book 7th edition
 * 
 */



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel contentPane;

	ArrayList<Question> myQuiz = null; // my quiz is an arrayList of the Question class
	Question QCurrent = null;
	
	final int N_PLAYERS = 2;  // allow for more players in the future - just make sure we have a multiple of that
								// number of questions created for them
	int iQNum = 0;    // current question
	int iPlayer = 0;  // number of current player
	int[] iScores = new int[N_PLAYERS];  // equivalent to new int[2]
	JTextArea txtrQuestions;
	JLabel lblPlayer ;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnDebug = new JButton("Debug");
		btnDebug.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// output our list of questions to confirm our array of Questions works
				// display each question in myQuiz just for testing
				for (Question q : myQuiz)
					txtrQuestions.append(q.toStringWithCorrect());

			}
		});
		btnDebug.setBounds(79, 234, 117, 29);
		contentPane.add(btnDebug);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(79, 42, 311, 112);
		contentPane.add(scrollPane);

		txtrQuestions = new JTextArea();
		scrollPane.setViewportView(txtrQuestions);
		txtrQuestions.setText("questions");

		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				answerClicked(1);
			}
		});
		btn1.setFont(new Font("Dialog", Font.BOLD, 18));
		btn1.setBounds(75, 161, 63, 44);
		contentPane.add(btn1);

		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				answerClicked(2);
			}
		});
		btn2.setFont(new Font("Dialog", Font.BOLD, 18));
		btn2.setBounds(160, 161, 63, 44);
		contentPane.add(btn2);

		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				answerClicked(3);
			}
		});
		btn3.setFont(new Font("Dialog", Font.BOLD, 18));
		btn3.setBounds(248, 161, 63, 44);
		contentPane.add(btn3);

		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				answerClicked(4);
			}
		});
		btn4.setFont(new Font("Dialog", Font.BOLD, 18));
		btn4.setBounds(323, 161, 63, 44);
		contentPane.add(btn4);
		
		lblPlayer = new JLabel("Player #1");
		lblPlayer.setFont(new Font("Dialog", Font.BOLD, 18));
		lblPlayer.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlayer.setBounds(79, 0, 307, 30);
		contentPane.add(lblPlayer);

		// create the quiz - put this in a separate method
		quizCreate(); // populate our quiz

		// set current question and scores
		iQNum = 0;
		QCurrent = myQuiz.get(0);
		questionDisplay(iQNum);

	}

	public void questionDisplay(int iNum) {
		
		// player number is 0 for the lower half of the questions
		iPlayer = (iQNum * N_PLAYERS )/  myQuiz.size();
		lblPlayer.setText("Player #" + (iPlayer + 1) );
		txtrQuestions.setText(""); // clear the question
		txtrQuestions.append(QCurrent.toString());
		
		
	}

	public void answerClicked(int iSelected) {
		// update score of current player if answer is correct
		System.out.println("Player selected " + iSelected + ", the correct answer was " + QCurrent.getCorrect());

		if( iSelected == QCurrent.getCorrect())
			iScores[iPlayer]++;  // increment the score for this player
		
		iQNum++;  // increment the current question
		if (iQNum < myQuiz.size()) {
			QCurrent = myQuiz.get(iQNum);
			questionDisplay(iQNum);
		} else {
			gameOver();
		}
	}

	public void gameOver() {
		// display scores and ending message
		this.txtrQuestions.setText("Results \n");
		for( int i =0; i<iScores.length; i++) {
			this.txtrQuestions.append("Player #" + (i+1)+ " score = " + iScores[i] + "\n");
		}
		System.out.println("Thanks for playing!");
	}

	public void quizCreate() {

		myQuiz = new ArrayList<>();
		ArrayList<String> aAnswers = new ArrayList<>();

		aAnswers.add("4");
		aAnswers.add("53");
		aAnswers.add("79"); // correct
		aAnswers.add("none");
		myQuiz.add(new Question("How many moons has Jupiter?", aAnswers, 3));

		// next question
		aAnswers.clear(); // start a new list
		aAnswers.add("Eo");
		aAnswers.add("Ganymede");
		aAnswers.add("Europa");
		aAnswers.add("Callisto");
		myQuiz.add(new Question("Which moon of Jupiter is the largest?", aAnswers, 2));
		
		//
		aAnswers.clear(); // start a new list
		aAnswers.add("484 Million miles");
		aAnswers.add("98 Million miles");
		aAnswers.add("200 Million miles");
		aAnswers.add("943 Million miles");
		myQuiz.add(new Question("How far is Jupiter from the Sun?", aAnswers, 1));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("800x");
		aAnswers.add("120x");
		aAnswers.add("10x");
		aAnswers.add("318x");
		myQuiz.add(new Question("How much more massive is Jupiter than Earth?", aAnswers, 4));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("5");
		aAnswers.add("10");
		aAnswers.add("20");
		aAnswers.add("40");
		myQuiz.add(new Question("Jupiter spins around completely in __ hours.", aAnswers, 2));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("Water vapor");
		aAnswers.add("Ice");
		aAnswers.add("Amonia");
		aAnswers.add("Freon");
		myQuiz.add(new Question("The clouds of Jupter are made of", aAnswers, 3));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("50 years");
		aAnswers.add("350 years");
		aAnswers.add("1000 years");
		aAnswers.add("2000");
		myQuiz.add(new Question("Jupiter's Great Red Spot has been around for at least", aAnswers, 2));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("Giovanni Cassini");
		aAnswers.add("Edward Hubbel. ");
		aAnswers.add("Santovina Magellan");
		aAnswers.add("Ricardo Columbus");
		myQuiz.add(new Question("The Great Red Spot was first spotted by", aAnswers, 1));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("half as strong");
		aAnswers.add("3 times stronger");
		aAnswers.add("14 times stronger");
		aAnswers.add("20 times stronger");
		myQuiz.add(new Question("Compared to Earth, Jupiters magnetic field is", aAnswers, 3));
		
		aAnswers.clear(); // start a new list
		aAnswers.add("3");
		aAnswers.add("5");
		aAnswers.add("7");
		aAnswers.add("9");
		myQuiz.add(new Question("The number of spacecraft that have visited Jupiter by 2019", aAnswers, 3));
		
		
		
		// now shuffle the questions into random order to make the game more interesting
		// get a question from a random position
		// shuffling withing a question is up to the Question class
		int iPos;
		Question qRandom = null;
		
		for( int i=0; i<myQuiz.size(); i++) {  // we could shuffle as many times as we like
			iPos = (int)(Math.random() * myQuiz.size());
		    qRandom = myQuiz.get(iPos);
		    myQuiz.remove(iPos);  // remove a question from a random position in the ArrayList
		    myQuiz.add(qRandom);  // add it back to the end of the list
		}
		
	}
}
