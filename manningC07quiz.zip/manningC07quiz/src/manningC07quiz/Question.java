package manningC07quiz;

/*
 * Question.java - hold a question and possible correct answers
 * 
 * This is part of a quiz program to practic the use of the Question object and array lists.
 */


import java.util.ArrayList;

public class Question {

	private String sQuestion;
	private ArrayList<String> sAnswers;
	private int iCorrect;
	
	// Constructor
	// provide question, an array of possible answers
	// and number of correct answer
	Question(String q, ArrayList<String> ans, int n) {
		sQuestion = q;
		sAnswers = new ArrayList<String>();
		for( String s : ans ) 
			sAnswers.add(s); // add answer to arraylist
		iCorrect = n;  // designate correct answer
	}
	
	
	// getter
	int getCorrect() {
		return iCorrect;
	}
	

	// generate question text with answer choices
	public String toString() {
		
		String s = sQuestion + "\n";
		
		int  n = 1;
		for( String sAns : sAnswers )
			s += "   " + n++ + " " + sAns + "\n";
		
		return s;
	}
	
	
	// show the question with correct answer marked
	public String toStringWithCorrect() {
		String s = sQuestion + "\n";
		
		int iCorrect = this.getCorrect();

		for( int n=0; n< sAnswers.size(); n++ ) {
		
			if( iCorrect == n )
				s += "  *";
			else
				s += "   ";
			
			s += " " + n + " " + sAnswers.get(n) ;

			
			s += "\n";
		}
		
		return s;
	}
}
